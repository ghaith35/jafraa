import { Suspense } from "react";
import Link from "next/link";
import { Plus } from "lucide-react";
import { redirect } from "next/navigation";
import { getSession } from "@/lib/auth/session";
import { hasPermission } from "@/lib/auth/permissions";
import { listSuppliers } from "@/features/inventory/actions/supplier.actions";
import { SupplierList } from "@/features/inventory/components/SupplierList";

export const metadata = { title: "Fournisseurs — REPAIRE" };

export default async function SuppliersPage(props: {
  searchParams: Promise<{ q?: string; archived?: string }>;
}) {
  const session = await getSession();
  if (!session) redirect("/login");
  if (!hasPermission(session.role, "inventory:manage")) redirect("/dashboard");

  const searchParams = await props.searchParams;
  const q = searchParams.q;
  const showArchived = searchParams.archived === "true";

  const suppliers = await listSuppliers({ q, showArchived });

  return (
    <div className="max-w-screen-xl mx-auto space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-foreground">
            Fournisseurs
          </h1>
          <p className="text-sm text-muted-foreground">
            Gérez vos fournisseurs et suivez vos soldes.
          </p>
        </div>
        <Link
          href="/dashboard/suppliers/new"
          className="inline-flex shrink-0 items-center gap-1.5 rounded-md bg-primary px-3 py-2 text-sm font-semibold text-primary-foreground hover:bg-primary/90 transition-colors"
        >
          <Plus className="h-4 w-4" />
          Nouveau fournisseur
        </Link>
      </div>

      <Suspense fallback={<div className="h-20 bg-muted animate-pulse rounded-md" />}>
        <SupplierList suppliers={suppliers} userRole={session.role} />
      </Suspense>
    </div>
  );
}
