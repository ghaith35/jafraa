import { PageHeader } from "@/components/shared/PageHeader";
import { AlertCircle } from "lucide-react";
import { WhatsAppManager } from "@/features/whatsapp/components/WhatsAppManager";
import { getStoreWhatsAppPhone, listWhatsAppLogs } from "@/features/whatsapp/actions/whatsapp.actions";
import type { WhatsAppNotificationLog } from "@prisma/client";

export const dynamic = "force-dynamic";
export const metadata = { title: "WhatsApp — REPAIRE" };

export default async function WhatsAppSettingsPage() {
  const [initialPhone, logs] = await Promise.all([
    getStoreWhatsAppPhone(),
    listWhatsAppLogs(100),
  ]);

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <PageHeader
        title="Notifications WhatsApp"
        description="Envoyez des messages WhatsApp pré-remplis à vos clients depuis les fiches réparation."
      />

      <WhatsAppManager
        initialPhone={initialPhone}
        logs={logs.map((l: WhatsAppNotificationLog) => ({
          id: l.id,
          phone: l.phone,
          entityType: l.entityType,
          entityId: l.entityId,
          messagePreview: l.messagePreview,
          createdAt: l.createdAt,
        }))}
      />

      <div className="rounded-xl border border-amber-200 bg-amber-50 p-4 dark:bg-amber-950/20 dark:border-amber-900/50 flex gap-3">
        <AlertCircle className="h-5 w-5 text-amber-600 shrink-0 mt-0.5" />
        <div className="text-sm text-amber-800 dark:text-amber-300">
          <p className="font-bold">Information</p>
          <p className="mt-1">
            Les messages sont envoyés manuellement via l&apos;application WhatsApp sur votre téléphone.
            Aucun message automatique n&apos;est envoyé sans votre confirmation.
          </p>
        </div>
      </div>
    </div>
  );
}
