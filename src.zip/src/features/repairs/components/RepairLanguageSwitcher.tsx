"use client";

import { useEffect, useMemo, useState } from "react";
import {
  getRepairDirection,
  isRepairLocale,
  REPAIR_LOCALE_OPTIONS,
  REPAIR_LOCALE_STORAGE_KEY,
  type RepairLocale,
  type RepairTranslationKey,
  tRepair,
  translateRepairMessage,
  formatRepairDate,
  formatRepairDateTime,
} from "../i18n";

const DEFAULT_LOCALE: RepairLocale = "en";
const CHANGE_EVENT = "repair-locale-change";

function readInitialLocale(): RepairLocale {
  if (typeof window === "undefined") return DEFAULT_LOCALE;

  const stored = window.localStorage.getItem(REPAIR_LOCALE_STORAGE_KEY);
  if (isRepairLocale(stored)) return stored;

  const htmlLang = document.documentElement.lang?.slice(0, 2);
  if (isRepairLocale(htmlLang)) return htmlLang;

  const browserLang = navigator.language?.slice(0, 2);
  if (isRepairLocale(browserLang)) return browserLang;

  return DEFAULT_LOCALE;
}

function applyDocumentLocale(locale: RepairLocale) {
  if (typeof document === "undefined") return;
  document.documentElement.lang = locale;
  document.documentElement.dir = getRepairDirection(locale);
}

export function useRepairI18n() {
  const [locale, setLocaleState] = useState<RepairLocale>(DEFAULT_LOCALE);

  useEffect(() => {
    const initial = readInitialLocale();
    setLocaleState(initial);
    applyDocumentLocale(initial);

    const onStorage = (event: StorageEvent) => {
      if (event.key === REPAIR_LOCALE_STORAGE_KEY && isRepairLocale(event.newValue)) {
        setLocaleState(event.newValue);
        applyDocumentLocale(event.newValue);
      }
    };

    const onLocaleChange = (event: Event) => {
      const next = (event as CustomEvent<RepairLocale>).detail;
      if (isRepairLocale(next)) {
        setLocaleState(next);
        applyDocumentLocale(next);
      }
    };

    window.addEventListener("storage", onStorage);
    window.addEventListener(CHANGE_EVENT, onLocaleChange);
    return () => {
      window.removeEventListener("storage", onStorage);
      window.removeEventListener(CHANGE_EVENT, onLocaleChange);
    };
  }, []);

  const value = useMemo(() => {
    const setLocale = (next: RepairLocale) => {
      window.localStorage.setItem(REPAIR_LOCALE_STORAGE_KEY, next);
      setLocaleState(next);
      applyDocumentLocale(next);
      window.dispatchEvent(new CustomEvent(CHANGE_EVENT, { detail: next }));
    };

    return {
      locale,
      dir: getRepairDirection(locale),
      setLocale,
      t: (key: RepairTranslationKey, params?: Record<string, string | number>) => tRepair(locale, key, params),
      formatDate: (value: string | number | Date) => formatRepairDate(value, locale),
      formatDateTime: (value: string | number | Date) => formatRepairDateTime(value, locale),
      trMessage: (message: unknown) => translateRepairMessage(message, locale),
    };
  }, [locale]);

  return value;
}

export function RepairLanguageSwitcher({ compact = false }: { compact?: boolean }) {
  const { locale, setLocale, t } = useRepairI18n();

  return (
    <label className="inline-flex items-center gap-2 text-xs font-medium text-muted-foreground">
      {!compact && <span>{t("language")}</span>}
      <select
        value={locale}
        onChange={(event) => setLocale(event.target.value as RepairLocale)}
        className="h-8 rounded-md border border-input bg-background px-2 text-xs text-foreground shadow-sm focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
      >
        {REPAIR_LOCALE_OPTIONS.map((option) => (
          <option key={option.value} value={option.value}>
            {option.nativeLabel}
          </option>
        ))}
      </select>
    </label>
  );
}
