export type RepairLocale = "en" | "ar";

type Params = Record<string, string | number>;

export const REPAIR_LOCALE_STORAGE_KEY = "repair_locale";

export const REPAIR_LOCALE_OPTIONS: Array<{ value: RepairLocale; label: string; nativeLabel: string; dir: "ltr" | "rtl" }> = [
  { value: "en", label: "English", nativeLabel: "English", dir: "ltr" },
  { value: "ar", label: "Arabic", nativeLabel: "العربية", dir: "rtl" },
];

export const repairTranslations = {
  en: {
    language: "Language",
    english: "English",
    arabic: "Arabic",
    cancel: "Cancel",
    change: "Change",
    action: "Action",
    date: "Date",
    status: "Status",
    quantityShort: "Qty",
    sku: "SKU",
    total: "Total",
    subtotal: "Subtotal",
    discount: "Discount",
    customer: "Customer",
    device: "Device",
    view: "View",
    urgent: "Urgent",
    unassigned: "Unassigned",
    createdOnBy: "Created on {date} by {name}",
    movedToStatus: "Moved to {status}",
    onDateBy: "On {date} by {name}",
    unknownDevice: "Unknown device",
    customerDevice: "Customer device",
    color: "Color",
    imeiSerial: "IMEI / Serial",
    password: "Password",

    status_received: "Received",
    status_in_diagnosis: "In diagnosis",
    status_waiting_customer_approval: "Waiting customer approval",
    status_in_repair: "In repair",
    status_ready_for_pickup: "Ready for pickup",
    status_completed: "Completed",
    status_not_repaired: "Not repaired",

    resolution_fixed: "Fixed",
    resolution_pending: "Pending",
    resolution_unresolved: "Unresolved",

    repairList_emptyTitle: "No repair tickets",
    repairList_emptyTechnician: "You do not have any assigned tickets yet.",
    repairList_emptyStaff: "Start by creating a new ticket for a customer.",
    repairList_ticketDevice: "Ticket / Device",
    repairList_technician: "Technician",
    repairList_due: "Due: {date}",

    form_unexpectedError: "An unexpected error occurred",
    form_sectionCustomer: "1. Customer",
    form_selectCustomer: "Select a customer *",
    form_chooseCustomer: "Choose a customer...",
    form_sectionDevice: "2. Device",
    form_existingDevice: "Existing device",
    form_newDeviceOption: "-- Enter a new device --",
    form_brand: "Brand *",
    form_brandPlaceholder: "Example: Apple, Samsung...",
    form_model: "Model *",
    form_modelPlaceholder: "Example: iPhone 13, Galaxy S21...",
    form_unlockCode: "Password / Code",
    form_unlockCodePlaceholder: "Unlock code",
    form_sectionProblems: "3. Reported problems *",
    form_addProblem: "Add problem",
    form_problemPlaceholder: "Problem description {index}...",
    form_sectionTracking: "4. Tracking",
    form_assignTechnician: "Assign to technician",
    form_doNotAssignNow: "-- Do not assign now --",
    form_priority: "Priority",
    form_priorityNormal: "Normal",
    form_priorityRush: "Urgent (Priority)",
    form_sectionNotes: "5. Notes (Optional)",
    form_internalNotes: "Internal notes (visible to the team)",
    form_internalNotesPlaceholder: "Example: Check the charging connector...",
    form_createTicket: "Create ticket",

    detail_reportedProblems: "Reported problems",
    detail_internalNotes: "Internal notes",
    detail_diagnosisNote: "Diagnosis note",
    detail_statusHistory: "Status history",

    invoice_line_labor: "Labor",
    invoice_line_part: "Part",
    invoice_line_service: "Service",
    invoice_line_custom: "Custom",
    invoice_repairLaborDescription: "Repair labor",
    invoice_status_unpaid: "Unpaid",
    invoice_status_partial: "Partially paid",
    invoice_status_paid: "Paid",
    invoice_status_cancelled: "Cancelled",
    invoice_payment: "Payment",
    invoice_cashReceived: "Cash received (DZD)",
    invoice_remaining: "Remaining amount",
    invoice_debtCreated: "Debt created: {amount} DZD will be recorded on the customer account",
    invoice_walkinFullPayment: "Walk-in customer — full cash payment required ({amount} DZD)",
    invoice_payAndFinish: "Collect payment & finish",
    invoice_partialPaymentHint: "Partial payment — the remainder will be recorded as debt",
    invoice_repairCompleted: "Repair completed",
    invoice_invoice: "Invoice",
    invoice_cashCollected: "Cash collected",
    invoice_recordedDebt: "Recorded debt",
    invoice_printInvoice: "Print invoice",
    invoice_completedNoInvoice: "Ticket completed — no invoice generated",
    invoice_noInvoiceGenerated: "No invoice generated",
    invoice_generateInvoice: "Generate invoice",
    invoice_noInvoiceAvailable: "No invoice available",
    invoice_ticket: "Ticket",
    invoice_description: "Description",
    invoice_unitPrice: "Unit price",
    invoice_alreadyPaid: "Already paid",
    invoice_totalRefunded: "Total refunded",
    invoice_remainingToPay: "Remaining to pay",
    invoice_fullyPaid: "Invoice fully paid",
    invoice_partiallyPaid: "Invoice partially paid",
    invoice_refund: "Refund",
    invoice_refundDone: "Refund completed",
    invoice_refundSummary: "{amount} DZD refunded under receipt {number}.",

    refund_title: "Invoice refund",
    refund_amount: "Amount (DZD)",
    refund_maxRefundable: "Max refundable",
    refund_reason: "Reason",
    refund_reasonPlaceholder: "Example: Defective screen after installation, commercial gesture...",
    refund_confirm: "Confirm refund",
    refund_amountPositive: "The amount must be greater than 0",
    refund_maxAmount: "Maximum refundable amount: {amount} DZD",
    refund_reasonRequired: "Please enter the refund reason",

    parts_title: "Reserved parts ({count})",
    parts_add: "Add part",
    parts_reserveTitle: "Reserve a part",
    parts_none: "No parts reserved for this ticket.",
    parts_searchLabel: "Search for a part (name, SKU, barcode)",
    parts_searchPlaceholder: "Search...",
    parts_availableShort: "Available: {available} / {stock}",
    parts_totalStock: "Total stock",
    parts_reserved: "Reserved",
    parts_available: "Available",
    parts_outOfStock: "Out of stock. This part cannot be reserved.",
    parts_noteOptional: "Note (optional)",
    parts_notePlaceholder: "Note...",
    parts_reserve: "Reserve",
    parts_part: "Part",
    parts_salePrice: "Sale price",
    parts_reservedBy: "Reserved by",
    parts_release: "Release",
    parts_confirmRelease: "Are you sure you want to release this reservation?",
    parts_history: "History ({count} released)",
    parts_releasedBy: "Released by",
    part_status_reserved: "Reserved",
    part_status_released: "Released",
    part_status_used: "Used",

    validation_describeProblem: "Please describe the problem",
    validation_selectCustomer: "Select a customer",
    validation_nonNegativePrice: "The price cannot be negative",
    validation_addProblem: "Please add at least one problem",
    validation_deviceRequired: "Please select an existing device or provide the new device details",
    validation_quantityPositive: "Quantity must be greater than 0",
    validation_insufficientStock: "Insufficient stock. Available: {available}",

    error_notAuthorized: "Not authorized",
    error_noStoreAssigned: "No store assigned",
    error_accessDenied: "Access denied",
    error_ticketNotFound: "Ticket not found",
    error_ticketNotFoundOrUnauthorized: "Ticket not found or unauthorized",
    error_actionNotAllowed: "Action not allowed",
    error_invalidData: "Invalid data",
    error_invalidStatus: "Invalid status",
    error_createTicket: "Error while creating the ticket",
    error_changeStatus: "Error while changing status",
    error_assign: "Error while assigning technician",
    error_technicianInvoice: "Technicians cannot generate invoices",
    error_technicianPayment: "Technicians cannot collect payments",
    error_invoiceExists: "An active invoice already exists for this ticket",
    error_invoiceGenerate: "Error while generating the invoice",
    error_invoiceNotFound: "Invoice not found",
    error_invoicePaid: "This invoice is already paid",
    error_invoiceCancelled: "This invoice has been cancelled",
    error_invoiceFullyPaid: "This invoice is already fully paid",
    error_cashNegative: "Received amount cannot be negative",
    error_walkinFullCash: "Walk-in customers must pay the full amount in cash",
    error_noCashSession: "No cash register session is open. Please open the cash register before collecting payment.",
    error_payment: "Error while processing payment",
    error_noCashSessionShort: "No cash register session is open.",
    error_cashierRefundCurrentSession: "Cashiers can only refund invoices from the current session.",
    error_refundDeferredDebt: "Refunds for invoices with debt are deferred. Contact an administrator.",
    error_refund: "Error while processing the refund",
    error_noStore: "No store",
    error_ticketArchived: "Ticket archived",
    error_reservationBlocked: "Cannot reserve parts on a completed or not repaired ticket",
    error_managerOnlyReady: "Only managers can reserve parts on a ticket ready for pickup",
    error_notAssigned: "You are not assigned to this ticket",
    error_partNotFound: "Part not found or archived",
    error_releaseUsed: "Cannot release a part that has already been used",
    error_reservationAlreadyReleased: "This reservation has already been released",
    error_reservationNotFound: "Reservation not found",
    error_reservePart: "Error while reserving the part",
    error_releasePart: "Error while releasing the part",
  },
  ar: {
    language: "اللغة",
    english: "English",
    arabic: "العربية",
    cancel: "إلغاء",
    change: "تغيير",
    action: "إجراء",
    date: "التاريخ",
    status: "الحالة",
    quantityShort: "الكمية",
    sku: "SKU",
    total: "المجموع",
    subtotal: "المجموع الفرعي",
    discount: "الخصم",
    customer: "العميل",
    device: "الجهاز",
    view: "عرض",
    urgent: "عاجل",
    unassigned: "غير معيّن",
    createdOnBy: "أُنشئ في {date} بواسطة {name}",
    movedToStatus: "تم نقله إلى {status}",
    onDateBy: "في {date} بواسطة {name}",
    unknownDevice: "جهاز غير معروف",
    customerDevice: "جهاز العميل",
    color: "اللون",
    imeiSerial: "IMEI / الرقم التسلسلي",
    password: "كلمة المرور",

    status_received: "تم الاستلام",
    status_in_diagnosis: "قيد التشخيص",
    status_waiting_customer_approval: "بانتظار موافقة العميل",
    status_in_repair: "قيد الإصلاح",
    status_ready_for_pickup: "جاهز للاستلام",
    status_completed: "مكتمل",
    status_not_repaired: "غير مُصلح",

    resolution_fixed: "تم الإصلاح",
    resolution_pending: "قيد الانتظار",
    resolution_unresolved: "غير محلول",

    repairList_emptyTitle: "لا توجد تذاكر إصلاح",
    repairList_emptyTechnician: "لا توجد تذاكر معيّنة لك حالياً.",
    repairList_emptyStaff: "ابدأ بإنشاء تذكرة جديدة لعميل.",
    repairList_ticketDevice: "التذكرة / الجهاز",
    repairList_technician: "التقني",
    repairList_due: "الموعد: {date}",

    form_unexpectedError: "حدث خطأ غير متوقع",
    form_sectionCustomer: "1. العميل",
    form_selectCustomer: "اختر عميلاً *",
    form_chooseCustomer: "اختر عميلاً...",
    form_sectionDevice: "2. الجهاز",
    form_existingDevice: "جهاز موجود",
    form_newDeviceOption: "-- إدخال جهاز جديد --",
    form_brand: "العلامة *",
    form_brandPlaceholder: "مثال: Apple, Samsung...",
    form_model: "الموديل *",
    form_modelPlaceholder: "مثال: iPhone 13, Galaxy S21...",
    form_unlockCode: "كلمة المرور / الكود",
    form_unlockCodePlaceholder: "كود الفتح",
    form_sectionProblems: "3. المشاكل المبلّغ عنها *",
    form_addProblem: "إضافة مشكلة",
    form_problemPlaceholder: "وصف المشكلة {index}...",
    form_sectionTracking: "4. المتابعة",
    form_assignTechnician: "تعيين تقني",
    form_doNotAssignNow: "-- لا تعيّن الآن --",
    form_priority: "الأولوية",
    form_priorityNormal: "عادية",
    form_priorityRush: "عاجلة (أولوية)",
    form_sectionNotes: "5. ملاحظات (اختياري)",
    form_internalNotes: "ملاحظات داخلية (ظاهرة للفريق)",
    form_internalNotesPlaceholder: "مثال: فحص منفذ الشحن...",
    form_createTicket: "إنشاء التذكرة",

    detail_reportedProblems: "المشاكل المبلّغ عنها",
    detail_internalNotes: "ملاحظات داخلية",
    detail_diagnosisNote: "ملاحظة التشخيص",
    detail_statusHistory: "سجل الحالات",

    invoice_line_labor: "يد عاملة",
    invoice_line_part: "قطعة",
    invoice_line_service: "خدمة",
    invoice_line_custom: "مخصص",
    invoice_repairLaborDescription: "يد عاملة الإصلاح",
    invoice_status_unpaid: "غير مدفوعة",
    invoice_status_partial: "مدفوعة جزئياً",
    invoice_status_paid: "مدفوعة",
    invoice_status_cancelled: "ملغاة",
    invoice_payment: "الدفع",
    invoice_cashReceived: "المبلغ المستلم (DZD)",
    invoice_remaining: "المبلغ المتبقي",
    invoice_debtCreated: "سيتم تسجيل دين بقيمة {amount} DZD على حساب العميل",
    invoice_walkinFullPayment: "عميل عابر — يجب دفع المبلغ كاملاً نقداً ({amount} DZD)",
    invoice_payAndFinish: "قبض الدفع وإنهاء الإصلاح",
    invoice_partialPaymentHint: "دفع جزئي — سيتم تسجيل الباقي كدين",
    invoice_repairCompleted: "تم إنهاء الإصلاح",
    invoice_invoice: "الفاتورة",
    invoice_cashCollected: "المبلغ المقبوض نقداً",
    invoice_recordedDebt: "الدين المسجل",
    invoice_printInvoice: "طباعة الفاتورة",
    invoice_completedNoInvoice: "التذكرة مكتملة — لم يتم إنشاء فاتورة",
    invoice_noInvoiceGenerated: "لم يتم إنشاء فاتورة",
    invoice_generateInvoice: "إنشاء الفاتورة",
    invoice_noInvoiceAvailable: "لا توجد فاتورة متاحة",
    invoice_ticket: "التذكرة",
    invoice_description: "الوصف",
    invoice_unitPrice: "سعر الوحدة",
    invoice_alreadyPaid: "مدفوع سابقاً",
    invoice_totalRefunded: "إجمالي المبلغ المُرجع",
    invoice_remainingToPay: "المتبقي للدفع",
    invoice_fullyPaid: "الفاتورة مدفوعة بالكامل",
    invoice_partiallyPaid: "الفاتورة مدفوعة جزئياً",
    invoice_refund: "استرجاع",
    invoice_refundDone: "تم الاسترجاع",
    invoice_refundSummary: "تم استرجاع {amount} DZD تحت وصل {number}.",

    refund_title: "استرجاع الفاتورة",
    refund_amount: "المبلغ (DZD)",
    refund_maxRefundable: "الحد الأقصى للاسترجاع",
    refund_reason: "السبب",
    refund_reasonPlaceholder: "مثال: شاشة معيبة بعد التركيب، تعويض تجاري...",
    refund_confirm: "تأكيد الاسترجاع",
    refund_amountPositive: "يجب أن يكون المبلغ أكبر من 0",
    refund_maxAmount: "أقصى مبلغ قابل للاسترجاع: {amount} DZD",
    refund_reasonRequired: "يرجى إدخال سبب الاسترجاع",

    parts_title: "القطع المحجوزة ({count})",
    parts_add: "إضافة قطعة",
    parts_reserveTitle: "حجز قطعة",
    parts_none: "لا توجد قطع محجوزة لهذه التذكرة.",
    parts_searchLabel: "البحث عن قطعة (الاسم، SKU، الباركود)",
    parts_searchPlaceholder: "بحث...",
    parts_availableShort: "متاح: {available} / {stock}",
    parts_totalStock: "إجمالي المخزون",
    parts_reserved: "محجوز",
    parts_available: "متاح",
    parts_outOfStock: "نفد المخزون. لا يمكن حجز هذه القطعة.",
    parts_noteOptional: "ملاحظة (اختياري)",
    parts_notePlaceholder: "ملاحظة...",
    parts_reserve: "حجز",
    parts_part: "القطعة",
    parts_salePrice: "سعر البيع",
    parts_reservedBy: "حُجزت بواسطة",
    parts_release: "تحرير",
    parts_confirmRelease: "هل أنت متأكد أنك تريد تحرير هذا الحجز؟",
    parts_history: "السجل ({count} محررة)",
    parts_releasedBy: "حُررت بواسطة",
    part_status_reserved: "محجوزة",
    part_status_released: "محررة",
    part_status_used: "مستخدمة",

    validation_describeProblem: "يرجى وصف المشكلة",
    validation_selectCustomer: "اختر عميلاً",
    validation_nonNegativePrice: "لا يمكن أن يكون السعر سالباً",
    validation_addProblem: "يرجى إضافة مشكلة واحدة على الأقل",
    validation_deviceRequired: "يرجى اختيار جهاز موجود أو إدخال تفاصيل الجهاز الجديد",
    validation_quantityPositive: "يجب أن تكون الكمية أكبر من 0",
    validation_insufficientStock: "المخزون غير كافٍ. المتاح: {available}",

    error_notAuthorized: "غير مصرح",
    error_noStoreAssigned: "لا توجد بوتيك معيّنة",
    error_accessDenied: "تم رفض الوصول",
    error_ticketNotFound: "التذكرة غير موجودة",
    error_ticketNotFoundOrUnauthorized: "التذكرة غير موجودة أو غير مصرح بها",
    error_actionNotAllowed: "الإجراء غير مسموح",
    error_invalidData: "بيانات غير صالحة",
    error_invalidStatus: "حالة غير صالحة",
    error_createTicket: "حدث خطأ أثناء إنشاء التذكرة",
    error_changeStatus: "حدث خطأ أثناء تغيير الحالة",
    error_assign: "حدث خطأ أثناء تعيين التقني",
    error_technicianInvoice: "لا يمكن للتقنيين إنشاء الفواتير",
    error_technicianPayment: "لا يمكن للتقنيين قبض المدفوعات",
    error_invoiceExists: "توجد فاتورة نشطة مسبقاً لهذه التذكرة",
    error_invoiceGenerate: "حدث خطأ أثناء إنشاء الفاتورة",
    error_invoiceNotFound: "الفاتورة غير موجودة",
    error_invoicePaid: "هذه الفاتورة مدفوعة مسبقاً",
    error_invoiceCancelled: "تم إلغاء هذه الفاتورة",
    error_invoiceFullyPaid: "هذه الفاتورة مدفوعة بالكامل مسبقاً",
    error_cashNegative: "لا يمكن أن يكون المبلغ المستلم سالباً",
    error_walkinFullCash: "يجب على العملاء العابرين دفع المبلغ كاملاً نقداً",
    error_noCashSession: "لا توجد جلسة صندوق مفتوحة. يرجى فتح الصندوق قبل قبض الدفع.",
    error_payment: "حدث خطأ أثناء الدفع",
    error_noCashSessionShort: "لا توجد جلسة صندوق مفتوحة.",
    error_cashierRefundCurrentSession: "يمكن للكاشير استرجاع فواتير جلسة الصندوق الحالية فقط.",
    error_refundDeferredDebt: "استرجاع الفواتير التي تحتوي على دين مؤجل. تواصل مع المدير.",
    error_refund: "حدث خطأ أثناء الاسترجاع",
    error_noStore: "لا توجد بوتيك",
    error_ticketArchived: "التذكرة مؤرشفة",
    error_reservationBlocked: "لا يمكن حجز قطع على تذكرة مكتملة أو غير مصلحة",
    error_managerOnlyReady: "يمكن للمديرين فقط حجز قطع على تذكرة جاهزة للاستلام",
    error_notAssigned: "أنت غير معيّن لهذه التذكرة",
    error_partNotFound: "القطعة غير موجودة أو مؤرشفة",
    error_releaseUsed: "لا يمكن تحرير قطعة تم استخدامها مسبقاً",
    error_reservationAlreadyReleased: "تم تحرير هذا الحجز مسبقاً",
    error_reservationNotFound: "الحجز غير موجود",
    error_reservePart: "حدث خطأ أثناء حجز القطعة",
    error_releasePart: "حدث خطأ أثناء تحرير القطعة",
  },
} as const;

export type RepairTranslationKey = keyof typeof repairTranslations.en;

export function isRepairLocale(value: unknown): value is RepairLocale {
  return value === "en" || value === "ar";
}

export function getRepairDirection(locale: RepairLocale): "ltr" | "rtl" {
  return locale === "ar" ? "rtl" : "ltr";
}

export function getRepairIntlLocale(locale: RepairLocale): string {
  return locale === "ar" ? "ar-DZ" : "en-GB";
}

export function tRepair(locale: RepairLocale, key: RepairTranslationKey, params?: Params): string {
  const template = repairTranslations[locale][key] || repairTranslations.en[key] || key;
  if (!params) return template;
  return Object.entries(params).reduce(
    (acc, [param, value]) => acc.replaceAll(`{${param}}`, String(value)),
    template
  );
}

export function formatRepairDate(value: string | number | Date, locale: RepairLocale): string {
  return new Intl.DateTimeFormat(getRepairIntlLocale(locale), {
    year: "numeric",
    month: "short",
    day: "numeric",
  }).format(new Date(value));
}

export function formatRepairDateTime(value: string | number | Date, locale: RepairLocale): string {
  return new Intl.DateTimeFormat(getRepairIntlLocale(locale), {
    year: "numeric",
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  }).format(new Date(value));
}

export function getRepairStatusLabel(status: string, locale: RepairLocale): string {
  const key = `status_${status}` as RepairTranslationKey;
  return key in repairTranslations.en ? tRepair(locale, key) : status;
}

export function getPartStatusLabel(status: string, locale: RepairLocale): string {
  const key = `part_status_${status}` as RepairTranslationKey;
  return key in repairTranslations.en ? tRepair(locale, key) : status;
}

export function getInvoiceStatusLabel(status: string, locale: RepairLocale): string {
  const key = `invoice_status_${status}` as RepairTranslationKey;
  return key in repairTranslations.en ? tRepair(locale, key) : status;
}

export function getLineTypeLabel(lineType: string, locale: RepairLocale): string {
  const key = `invoice_line_${lineType}` as RepairTranslationKey;
  return key in repairTranslations.en ? tRepair(locale, key) : lineType;
}

const messageKeys: Record<string, RepairTranslationKey> = {
  "Veuillez décrire le problème": "validation_describeProblem",
  "Sélectionnez un client": "validation_selectCustomer",
  "Le prix ne peut pas être négatif": "validation_nonNegativePrice",
  "Veuillez ajouter au moins un problème": "validation_addProblem",
  "Veuillez sélectionner un appareil existant ou fournir les détails du nouvel appareil": "validation_deviceRequired",
  "La quantité doit être supérieure à 0": "validation_quantityPositive",
  "Non autorisé": "error_notAuthorized",
  "Aucune boutique assignée": "error_noStoreAssigned",
  "Aucune boutique": "error_noStore",
  "Accès refusé": "error_accessDenied",
  "Action non autorisée": "error_actionNotAllowed",
  "Données invalides": "error_invalidData",
  "Statut invalide": "error_invalidStatus",
  "Erreur lors de la création du ticket": "error_createTicket",
  "Erreur lors du changement de statut": "error_changeStatus",
  "Erreur lors de l'assignation": "error_assign",
  "Ticket introuvable": "error_ticketNotFound",
  "Ticket introuvable ou non autorisé": "error_ticketNotFoundOrUnauthorized",
  "Les techniciens ne peuvent pas générer de factures": "error_technicianInvoice",
  "Les techniciens ne peuvent pas encaisser": "error_technicianPayment",
  "Une facture active existe déjà pour ce ticket": "error_invoiceExists",
  "Erreur lors de la génération de la facture": "error_invoiceGenerate",
  "Facture introuvable": "error_invoiceNotFound",
  "Cette facture est déjà réglée": "error_invoicePaid",
  "Cette facture a été annulée": "error_invoiceCancelled",
  "Cette facture est déjà entièrement réglée": "error_invoiceFullyPaid",
  "Le montant reçu ne peut pas être négatif": "error_cashNegative",
  "Les clients de passage doivent payer la totalité en espèces": "error_walkinFullCash",
  "Aucune session de caisse ouverte. Veuillez ouvrir la caisse avant d'encaisser.": "error_noCashSession",
  "Aucune session de caisse ouverte.": "error_noCashSessionShort",
  "Erreur lors du paiement": "error_payment",
  "Le montant doit être supérieur à 0": "refund_amountPositive",
  "Veuillez indiquer le motif du remboursement": "refund_reasonRequired",
  "Les caissiers ne peuvent rembourser que les factures de la session en cours.": "error_cashierRefundCurrentSession",
  "Le remboursement des factures avec dette est différé. Contactez un administrateur.": "error_refundDeferredDebt",
  "Erreur lors du remboursement": "error_refund",
  "Ticket archivé": "error_ticketArchived",
  "Impossible de réserver des pièces sur un ticket terminé ou non réparé": "error_reservationBlocked",
  "Seuls les gérants peuvent réserver des pièces sur un ticket prêt à retirer": "error_managerOnlyReady",
  "Vous n'êtes pas assigné à ce ticket": "error_notAssigned",
  "Pièce introuvable ou archivée": "error_partNotFound",
  "Impossible de libérer une pièce déjà utilisée": "error_releaseUsed",
  "Cette réservation a déjà été libérée": "error_reservationAlreadyReleased",
  "Réservation introuvable": "error_reservationNotFound",
  "Erreur lors de la réservation": "error_reservePart",
  "Erreur lors de la libération": "error_releasePart",
};

export function translateRepairMessage(message: unknown, locale: RepairLocale): string {
  if (!message) return "";
  const raw = String(message);
  const key = messageKeys[raw];
  if (key) return tRepair(locale, key);

  const stockMatch = raw.match(/^Stock insuffisant\. Disponible: (\d+)$/);
  if (stockMatch) {
    return tRepair(locale, "validation_insufficientStock", { available: stockMatch[1] });
  }

  const maxRefundMatch = raw.match(/^Montant maximum remboursable: ([\d.]+) DZD$/);
  if (maxRefundMatch) {
    return tRepair(locale, "refund_maxAmount", { amount: maxRefundMatch[1] });
  }

  return raw;
}
