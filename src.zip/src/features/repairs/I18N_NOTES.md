# Repair module i18n notes

This repair module now includes English and Arabic UI support.

## Added files

- `repairs/i18n.ts`
  - Central English/Arabic translation dictionary.
  - Locale helpers, date formatting helpers, status labels, and server/validation message translation mapping.
- `repairs/components/RepairLanguageSwitcher.tsx`
  - Client-side language switcher.
  - Persists the selected language in `localStorage` using the key `repair_locale`.
  - Applies `document.documentElement.lang` and `document.documentElement.dir` automatically.

## Updated areas

- Repair list and empty states.
- Repair creation form labels, placeholders, priorities, buttons, and validation messages.
- Repair detail page labels, statuses, history, customer/device cards, and RTL layout attributes.
- Reserved parts search, reservation form, tables, statuses, confirmations, and errors.
- Invoice generation/payment/refund section labels, status badges, line type labels, totals, confirmations, and errors.

## Locale behavior

- Supported locales: `en`, `ar`.
- Default: English.
- Arabic automatically uses RTL direction.
- The switcher broadcasts a `repair-locale-change` event so multiple repair components on the page update together.

## Important integration note

The uploaded ZIP contained only the `repairs` feature folder, not the full app layout. Therefore, the language switcher is added inside the repair components themselves. If your full app already has a global language setting, connect it by setting `localStorage.setItem("repair_locale", "en" | "ar")` or by replacing `RepairLanguageSwitcher` with your global selector.
